# WebAppWithDatabaseDemo
Sample ASP.NET Core MVC app with database for demoing CI-CD pipelines using VSTS 

https://www.youtube.com/watch?v=uVne2HXkWXI&list=PLpbcUe4chE78FEvDjD9zfzSGvsdkvkkrj&index=1
